export { default } from "./InputTravelPage.js";
